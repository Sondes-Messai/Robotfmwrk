import Query from "./Query";
import Mutation from "./Mutation";

const items = {
  Query,
  Mutation,
};

export default items;
